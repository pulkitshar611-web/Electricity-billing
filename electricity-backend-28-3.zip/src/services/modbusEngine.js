const ModbusRTU = require('modbus-serial');
const prisma = require('../config/prisma');

class ModbusEngine {
    constructor() {
        this.clients = new Map(); // meterId -> client instance
        this.pollingInterval = null;
        this.io = null;
    }

    init(io) {
        this.io = io;
        console.log('Modbus Engine Initialized');
        this.startPolling();
    }

    async connectToMeter(meter) {
        let client = this.clients.get(meter.id);
        
        if (client && client.isOpen) {
            return client;
        }

        client = new ModbusRTU();
        try {
            if (meter.connectionType === 'TCP') {
                await client.connectTCP(meter.ipAddress, { port: meter.port });
            } else if (meter.connectionType === 'RS485') {
                await client.connectRTUBuffered(meter.comPort, {
                    baudRate: meter.baudRate,
                    dataBits: meter.dataBits,
                    stopBits: meter.stopBits,
                    parity: meter.parity
                });
            }
            
            client.setID(meter.modbusAddress);
            client.setTimeout(2000);
            this.clients.set(meter.id, client);
            
            console.log(`Connected to Meter: ${meter.meterName} (${meter.meterId})`);
            return client;
        } catch (error) {
            console.error(`Connection Error (Meter ${meter.meterId}):`, error.message);
            return null;
        }
    }

    async readMeterData(meter) {
        const client = await this.connectToMeter(meter);
        if (!client) return null;

        const results = {};
        for (const reg of meter.registers) {
            try {
                let data;
                if (reg.functionCode === 3) {
                    data = await client.readHoldingRegisters(reg.address, 2);
                } else if (reg.functionCode === 4) {
                    data = await client.readInputRegisters(reg.address, 2);
                }

                if (data && data.buffer) {
                    if (reg.dataType === 'Float') {
                        results[reg.label] = data.buffer.readFloatBE(0).toFixed(2);
                    } else if (reg.dataType === 'Int32') {
                        results[reg.label] = data.buffer.readInt32BE(0);
                    } else {
                        results[reg.label] = data.data[0];
                    }
                }
            } catch (error) {
                console.error(`Read Error (Meter ${meter.meterId}, Reg ${reg.label}):`, error.message);
                results[reg.label] = 'Error';
            }
        }
        return results;
    }

    async startPolling() {
        if (this.pollingInterval) clearInterval(this.pollingInterval);

        this.pollingInterval = setInterval(async () => {
            try {
                const meters = await prisma.meter.findMany({
                    include: { 
                        registers: true,
                        consumer: { include: { user: { select: { name: true } } } }
                    }
                });

                for (const meter of meters) {
                    if (meter.status === 'Connected' || true) { // Force poll for now
                        const data = await this.readMeterData(meter);
                        if (data) {
                            const payload = {
                                meterId: meter.meterId,
                                meterName: meter.meterName,
                                consumerName: meter.consumer.user.name,
                                ...data,
                                status: 'Connected',
                                lastUpdated: new Date()
                            };
                            
                            if (this.io) {
                                this.io.emit('meterUpdate', payload);
                            }
                        }
                    }
                }
            } catch (error) {
                console.error('Polling Engine Error:', error);
            }
        }, 3000); // Polling every 3 seconds
    }
}

module.exports = new ModbusEngine();
